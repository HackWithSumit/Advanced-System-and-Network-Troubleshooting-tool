# Advanced Disk Information Tool
# Programmed by: Sumit Ghosh
# Phone: 7076501101
# Email: cybersertex@outlook.com

Clear-Host
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Advanced Disk Information Tool" -ForegroundColor Yellow
Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

do {
    Write-Host "Please select an option:" -ForegroundColor White
    Write-Host "1. Disk Drive Information" -ForegroundColor Cyan
    Write-Host "2. Logical Disk Information" -ForegroundColor Cyan
    Write-Host "3. Disk Space Usage" -ForegroundColor Cyan
    Write-Host "4. Physical Disk Information" -ForegroundColor Cyan
    Write-Host "5. Disk Partitions" -ForegroundColor Cyan
    Write-Host "6. Volume Information" -ForegroundColor Cyan
    Write-Host "7. Check Disk Health" -ForegroundColor Cyan
    Write-Host "8. Exit" -ForegroundColor Red
    Write-Host ""
    
    $choice = Read-Host "Enter your choice (1-8)"
    
    switch ($choice) {
        "1" {
            Write-Host "`n============== Disk Drive Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_DiskDrive | Format-Table Model, Size, MediaType, InterfaceType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "2" {
            Write-Host "`n============== Logical Disk Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_LogicalDisk | Format-Table DeviceID, FileSystem, Size, FreeSpace, VolumeName -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "3" {
            Write-Host "`n============== Disk Space Usage ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_LogicalDisk | ForEach-Object {
                $SizeGB = [Math]::Round($_.Size / 1GB, 2)
                $FreeGB = [Math]::Round($_.FreeSpace / 1GB, 2)
                $UsedGB = $SizeGB - $FreeGB
                $PercentFree = [Math]::Round(($_.FreeSpace / $_.Size) * 100, 2)
                
                Write-Host "Drive: $($_.DeviceID)" -ForegroundColor Yellow
                Write-Host "  Total Size: $SizeGB GB" -ForegroundColor Cyan
                Write-Host "  Used Space: $UsedGB GB" -ForegroundColor Cyan
                Write-Host "  Free Space: $FreeGB GB" -ForegroundColor Cyan
                Write-Host "  Percent Free: $PercentFree%" -ForegroundColor Cyan
                Write-Host ""
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "4" {
            Write-Host "`n============== Physical Disk Information ==============" -ForegroundColor Green
            Get-PhysicalDisk | Format-Table DeviceId, FriendlyName, Size, MediaType, HealthStatus, OperationalStatus -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "5" {
            Write-Host "`n============== Disk Partitions ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_DiskPartition | Format-Table DiskIndex, Index, Size, Type, Bootable, PrimaryPartition -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "6" {
            Write-Host "`n============== Volume Information ==============" -ForegroundColor Green
            Get-Volume | Format-Table DriveLetter, FileSystemLabel, FileSystem, Size, SizeRemaining, HealthStatus -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "7" {
            Write-Host "`n============== Disk Health Check ==============" -ForegroundColor Green
            try {
                $disks = Get-PhysicalDisk
                foreach ($disk in $disks) {
                    Write-Host "Disk: $($disk.FriendlyName)" -ForegroundColor Yellow
                    Write-Host "  Health Status: $($disk.HealthStatus)" -ForegroundColor Cyan
                    Write-Host "  Operational Status: $($disk.OperationalStatus)" -ForegroundColor Cyan
                    Write-Host ""
                }
            } catch {
                Write-Host "Unable to retrieve disk health information." -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "8" {
            Write-Host "Exiting..." -ForegroundColor Red
            exit
        }
        default {
            Write-Host "Invalid choice. Please try again." -ForegroundColor Red
        }
    }
    Clear-Host
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "      Advanced Disk Information Tool" -ForegroundColor Yellow
    Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
    Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
} while ($choice -ne "8")
