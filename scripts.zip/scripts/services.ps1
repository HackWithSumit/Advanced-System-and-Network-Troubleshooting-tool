# Advanced Services Management Tool
# Programmed by: Sumit Ghosh
# Phone: 7076501101
# Email: cybersertex@outlook.com

Clear-Host
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Advanced Services Management Tool" -ForegroundColor Yellow
Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

do {
    Write-Host "Please select an option:" -ForegroundColor White
    Write-Host "1. Show All Services" -ForegroundColor Cyan
    Write-Host "2. Show Running Services" -ForegroundColor Cyan
    Write-Host "3. Show Stopped Services" -ForegroundColor Cyan
    Write-Host "4. Search Service by Name" -ForegroundColor Cyan
    Write-Host "5. Start a Service" -ForegroundColor Cyan
    Write-Host "6. Stop a Service" -ForegroundColor Cyan
    Write-Host "7. Restart a Service" -ForegroundColor Cyan
    Write-Host "8. Service Status Details" -ForegroundColor Cyan
    Write-Host "9. Show Automatic Services" -ForegroundColor Cyan
    Write-Host "10. Exit" -ForegroundColor Red
    Write-Host ""
    
    $choice = Read-Host "Enter your choice (1-10)"
    
    switch ($choice) {
        "1" {
            Write-Host "`n============== All Services ==============" -ForegroundColor Green
            Get-Service | Sort-Object Status, Name | Format-Table Name, Status, StartType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "2" {
            Write-Host "`n============== Running Services ==============" -ForegroundColor Green
            Get-Service | Where-Object {$_.Status -eq "Running"} | Sort-Object Name | Format-Table Name, Status, StartType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "3" {
            Write-Host "`n============== Stopped Services ==============" -ForegroundColor Green
            Get-Service | Where-Object {$_.Status -eq "Stopped"} | Sort-Object Name | Format-Table Name, Status, StartType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "4" {
            Write-Host "`n============== Search Service by Name ==============" -ForegroundColor Green
            $serviceName = Read-Host "Enter service name (or part of it) to search"
            $services = Get-Service -Name "*$serviceName*" -ErrorAction SilentlyContinue
            if ($services) {
                $services | Format-Table Name, Status, StartType -AutoSize
            } else {
                Write-Host "No services found containing '$serviceName'" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "5" {
            Write-Host "`n============== Start a Service ==============" -ForegroundColor Green
            $serviceName = Read-Host "Enter exact service name to start"
            try {
                $service = Get-Service -Name $serviceName -ErrorAction Stop
                if ($service.Status -eq "Running") {
                    Write-Host "Service '$serviceName' is already running." -ForegroundColor Yellow
                } else {
                    Start-Service -Name $serviceName
                    Write-Host "Service '$serviceName' started successfully." -ForegroundColor Green
                }
            } catch {
                Write-Host "Error: Service '$serviceName' not found or cannot be started." -ForegroundColor Red
                Write-Host "Error details: $($_.Exception.Message)" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "6" {
            Write-Host "`n============== Stop a Service ==============" -ForegroundColor Green
            $serviceName = Read-Host "Enter exact service name to stop"
            try {
                $service = Get-Service -Name $serviceName -ErrorAction Stop
                if ($service.Status -eq "Stopped") {
                    Write-Host "Service '$serviceName' is already stopped." -ForegroundColor Yellow
                } else {
                    $confirm = Read-Host "Are you sure you want to stop '$serviceName'? (Y/N)"
                    if ($confirm -eq "Y" -or $confirm -eq "y") {
                        Stop-Service -Name $serviceName -Force
                        Write-Host "Service '$serviceName' stopped successfully." -ForegroundColor Green
                    }
                }
            } catch {
                Write-Host "Error: Service '$serviceName' not found or cannot be stopped." -ForegroundColor Red
                Write-Host "Error details: $($_.Exception.Message)" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "7" {
            Write-Host "`n============== Restart a Service ==============" -ForegroundColor Green
            $serviceName = Read-Host "Enter exact service name to restart"
            try {
                $service = Get-Service -Name $serviceName -ErrorAction Stop
                $confirm = Read-Host "Are you sure you want to restart '$serviceName'? (Y/N)"
                if ($confirm -eq "Y" -or $confirm -eq "y") {
                    Restart-Service -Name $serviceName -Force
                    Write-Host "Service '$serviceName' restarted successfully." -ForegroundColor Green
                }
            } catch {
                Write-Host "Error: Service '$serviceName' not found or cannot be restarted." -ForegroundColor Red
                Write-Host "Error details: $($_.Exception.Message)" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "8" {
            Write-Host "`n============== Service Status Details ==============" -ForegroundColor Green
            $serviceName = Read-Host "Enter exact service name for details"
            try {
                $service = Get-Service -Name $serviceName -ErrorAction Stop
                $wmiService = Get-WmiObject -Class Win32_Service -Filter "Name='$serviceName'"
                
                Write-Host "`nService Details:" -ForegroundColor Yellow
                Write-Host "Name: $($service.Name)" -ForegroundColor Cyan
                Write-Host "Display Name: $($service.DisplayName)" -ForegroundColor Cyan
                Write-Host "Status: $($service.Status)" -ForegroundColor Cyan
                Write-Host "Start Type: $($service.StartType)" -ForegroundColor Cyan
                Write-Host "Description: $($wmiService.Description)" -ForegroundColor Cyan
                Write-Host "Path: $($wmiService.PathName)" -ForegroundColor Cyan
                Write-Host "Start Name: $($wmiService.StartName)" -ForegroundColor Cyan
            } catch {
                Write-Host "Error: Service '$serviceName' not found." -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "9" {
            Write-Host "`n============== Automatic Services ==============" -ForegroundColor Green
            Get-Service | Where-Object {$_.StartType -eq "Automatic"} | Sort-Object Name | Format-Table Name, Status, StartType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "10" {
            Write-Host "Exiting..." -ForegroundColor Red
            exit
        }
        default {
            Write-Host "Invalid choice. Please try again." -ForegroundColor Red
        }
    }
    Clear-Host
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "      Advanced Services Management Tool" -ForegroundColor Yellow
    Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
    Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
} while ($choice -ne "10")
