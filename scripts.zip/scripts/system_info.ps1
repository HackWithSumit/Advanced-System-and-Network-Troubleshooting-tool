# Advanced System Information Tool
# Programmed by: Sumit Ghosh
# Phone: 7076501101
# Email: cybersertex@outlook.com

Clear-Host
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Advanced System Information Tool" -ForegroundColor Yellow
Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

do {
    Write-Host "Please select an option:" -ForegroundColor White
    Write-Host "1. Computer System Information" -ForegroundColor Cyan
    Write-Host "2. Operating System Information" -ForegroundColor Cyan
    Write-Host "3. Processor Information" -ForegroundColor Cyan
    Write-Host "4. Memory Information" -ForegroundColor Cyan
    Write-Host "5. BIOS Information" -ForegroundColor Cyan
    Write-Host "6. Motherboard Information" -ForegroundColor Cyan
    Write-Host "7. Installed Software" -ForegroundColor Cyan
    Write-Host "8. Environment Variables" -ForegroundColor Cyan
    Write-Host "9. All System Information" -ForegroundColor Yellow
    Write-Host "10. Exit" -ForegroundColor Red
    Write-Host ""
    
    $choice = Read-Host "Enter your choice (1-10)"
    
    switch ($choice) {
        "1" {
            Write-Host "`n============== Computer System Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_ComputerSystem | Format-List Name, Manufacturer, Model, TotalPhysicalMemory, NumberOfProcessors
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "2" {
            Write-Host "`n============== Operating System Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_OperatingSystem | Format-List Caption, Version, BuildNumber, InstallDate, LastBootUpTime, TotalVisibleMemorySize, FreePhysicalMemory
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "3" {
            Write-Host "`n============== Processor Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_Processor | Format-List Name, Manufacturer, MaxClockSpeed, NumberOfCores, NumberOfLogicalProcessors, Architecture
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "4" {
            Write-Host "`n============== Memory Information ==============" -ForegroundColor Green
            $memory = Get-WmiObject -Class Win32_ComputerSystem
            $totalMemoryGB = [Math]::Round($memory.TotalPhysicalMemory / 1GB, 2)
            Write-Host "Total Physical Memory: $totalMemoryGB GB" -ForegroundColor Cyan
            
            Get-WmiObject -Class Win32_PhysicalMemory | Format-Table Manufacturer, Capacity, Speed, MemoryType -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "5" {
            Write-Host "`n============== BIOS Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_BIOS | Format-List Manufacturer, Name, Version, SerialNumber, ReleaseDate
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "6" {
            Write-Host "`n============== Motherboard Information ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_BaseBoard | Format-List Manufacturer, Product, Version, SerialNumber
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "7" {
            Write-Host "`n============== Installed Software (First 20) ==============" -ForegroundColor Green
            Get-WmiObject -Class Win32_Product | Select-Object Name, Version, Vendor | Sort-Object Name | Select-Object -First 20 | Format-Table -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "8" {
            Write-Host "`n============== Environment Variables ==============" -ForegroundColor Green
            Get-ChildItem Env: | Sort-Object Name | Format-Table Name, Value -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "9" {
            Write-Host "`n============== Complete System Information ==============" -ForegroundColor Green
            systeminfo
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "10" {
            Write-Host "Exiting..." -ForegroundColor Red
            exit
        }
        default {
            Write-Host "Invalid choice. Please try again." -ForegroundColor Red
        }
    }
    Clear-Host
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "      Advanced System Information Tool" -ForegroundColor Yellow
    Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
    Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
} while ($choice -ne "10")
