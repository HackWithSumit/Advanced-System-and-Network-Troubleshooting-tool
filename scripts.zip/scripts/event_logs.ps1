# Advanced Event Log Management Tool
# Programmed by: Sumit Ghosh
# Phone: 7076501101
# Email: cybersertex@outlook.com

Clear-Host
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "      Advanced Event Log Management Tool" -ForegroundColor Yellow
Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

do {
    Write-Host "Please select an option:" -ForegroundColor White
    Write-Host "1. System Event Log (Last 20 entries)" -ForegroundColor Cyan
    Write-Host "2. Application Event Log (Last 20 entries)" -ForegroundColor Cyan
    Write-Host "3. Security Event Log (Last 20 entries)" -ForegroundColor Cyan
    Write-Host "4. Error Events (Last 20)" -ForegroundColor Cyan
    Write-Host "5. Warning Events (Last 20)" -ForegroundColor Cyan
    Write-Host "6. Critical Events (Last 20)" -ForegroundColor Cyan
    Write-Host "7. Search Events by Source" -ForegroundColor Cyan
    Write-Host "8. Search Events by Event ID" -ForegroundColor Cyan
    Write-Host "9. Export Event Log to File" -ForegroundColor Cyan
    Write-Host "10. Exit" -ForegroundColor Red
    Write-Host ""
    
    $choice = Read-Host "Enter your choice (1-10)"
    
    switch ($choice) {
        "1" {
            Write-Host "`n============== System Event Log ==============" -ForegroundColor Green
            Get-EventLog -LogName System -Newest 20 | Format-Table TimeGenerated, EntryType, Source, EventID, Message -Wrap -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "2" {
            Write-Host "`n============== Application Event Log ==============" -ForegroundColor Green
            Get-EventLog -LogName Application -Newest 20 | Format-Table TimeGenerated, EntryType, Source, EventID, Message -Wrap -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "3" {
            Write-Host "`n============== Security Event Log ==============" -ForegroundColor Green
            try {
                Get-EventLog -LogName Security -Newest 20 | Format-Table TimeGenerated, EntryType, Source, EventID, Message -Wrap -AutoSize
            } catch {
                Write-Host "Access denied. Administrator privileges required for Security log." -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "4" {
            Write-Host "`n============== Error Events ==============" -ForegroundColor Green
            Get-EventLog -LogName System -EntryType Error -Newest 20 | Format-Table TimeGenerated, Source, EventID, Message -Wrap -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "5" {
            Write-Host "`n============== Warning Events ==============" -ForegroundColor Green
            Get-EventLog -LogName System -EntryType Warning -Newest 20 | Format-Table TimeGenerated, Source, EventID, Message -Wrap -AutoSize
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "6" {
            Write-Host "`n============== Critical Events ==============" -ForegroundColor Green
            # Use Get-WinEvent for better filtering of critical events
            try {
                Get-WinEvent -FilterHashtable @{LogName='System'; Level=1} -MaxEvents 20 | Format-Table TimeCreated, LevelDisplayName, Id, ProviderName, Message -Wrap -AutoSize
            } catch {
                Write-Host "No critical events found or access denied." -ForegroundColor Yellow
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "7" {
            Write-Host "`n============== Search Events by Source ==============" -ForegroundColor Green
            $source = Read-Host "Enter source name to search"
            $events = Get-EventLog -LogName System -Source $source -Newest 20 -ErrorAction SilentlyContinue
            if ($events) {
                $events | Format-Table TimeGenerated, EntryType, EventID, Message -Wrap -AutoSize
            } else {
                Write-Host "No events found for source '$source'" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "8" {
            Write-Host "`n============== Search Events by Event ID ==============" -ForegroundColor Green
            $eventId = Read-Host "Enter Event ID to search"
            $events = Get-EventLog -LogName System | Where-Object {$_.EventID -eq $eventId} | Select-Object -First 20
            if ($events) {
                $events | Format-Table TimeGenerated, EntryType, Source, Message -Wrap -AutoSize
            } else {
                Write-Host "No events found with Event ID '$eventId'" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "9" {
            Write-Host "`n============== Export Event Log ==============" -ForegroundColor Green
            $logName = Read-Host "Enter log name (System, Application, Security)"
            $fileName = Read-Host "Enter output file name (without extension)"
            $filePath = "$env:USERPROFILE\Desktop\$fileName.csv"
            
            try {
                Get-EventLog -LogName $logName -Newest 100 | Export-Csv -Path $filePath -NoTypeInformation
                Write-Host "Event log exported to: $filePath" -ForegroundColor Green
            } catch {
                Write-Host "Error exporting log: $($_.Exception.Message)" -ForegroundColor Red
            }
            Write-Host "Press any key to continue..." -ForegroundColor Yellow
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "10" {
            Write-Host "Exiting..." -ForegroundColor Red
            exit
        }
        default {
            Write-Host "Invalid choice. Please try again." -ForegroundColor Red
        }
    }
    Clear-Host
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host "      Advanced Event Log Management Tool" -ForegroundColor Yellow
    Write-Host "    Programmed by: Sumit Ghosh" -ForegroundColor Green
    Write-Host "    Email: cybersertex@outlook.com" -ForegroundColor Green
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host ""
} while ($choice -ne "10")
